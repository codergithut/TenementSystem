const Mock = require('mockjs')
let backDatas = {
    code: 0,
    data: '2018002151202112',
    msg: 'ok'
}
module.exports = reponse
function reponse (param) {
    return backDatas
}