let backDatas = {
    code: 0,
    data: {
        'id': '20171209144628513'
    },
    msg: 'ok'
}
module.exports = reponse
function reponse (param) {
    return backDatas
}