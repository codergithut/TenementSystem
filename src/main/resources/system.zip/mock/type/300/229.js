const Mock = require('mockjs')
let backDatas = {
    code: 0,
    data: null,
    msg: '取消收藏成功'
}
module.exports = reponse
function reponse (param) {
    return backDatas
}