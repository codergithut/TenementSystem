let backDatas = {
    code: 0,
    data: {
      "attendance": [
        {
            "check_time": "2018-05-12 08:34",
            "check_type": "考勤机",
            "emp_name": "唐龙",
            "gro_name": "默认部门",
            "io": 1
        },
        {
		  "check_time": "2018-05-12 18:23",
            "check_type": "考勤机",
            "emp_name": "唐龙",
            "gro_name": "默认部门",
            "io": 2
        },
	  {
		  "check_time": "2018-05-12 19:23",
            "check_type": "考勤机",
            "emp_name": "唐龙",
            "gro_name": "默认部门",
            "io": 1
        }
    ]
},
    msg: 'ok'
}
module.exports = reponse
function reponse (param) {
    return backDatas
}
