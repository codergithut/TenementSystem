import Home from '../view/home.js'
import Detail from '../view/detail.js'

export default [
  {
    path: '/home',
    component: Home
  },
  {
    path: '/detail',
    component: Detail
  }
]
