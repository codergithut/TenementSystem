export const Result = (text) => {
    return { type: 'SNAPSHOT_RESULT', text: text }
}