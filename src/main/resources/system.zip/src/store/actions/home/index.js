export const ExportNews = (news_id) => {
    return {
        type: 'HOME-INDEX',
        news_id: news_id
    }
}