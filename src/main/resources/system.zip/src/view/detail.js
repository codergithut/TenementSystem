import React from 'react'
import { List } from 'antd'

const data = [
  'Racing car sprays burning fuel into crowd.',
  'Japanese princess to wed commoner.',
  'Australian walks 100km after outback crash.',
  'Man charged over missing wedding girl.',
  'Los Angeles battles huge wildfires.'
]

class Detail extends React.Component {
  render() {
    return (
      <div style={{ padding: 50, height: '100%' }}>
        <div style={{ background: '#fff' }}>
          <div>
            <h3 style={{ marginBottom: 16 }}>Default Size</h3>
            <List
              header={<div>Header</div>}
              footer={<div>Footer</div>}
              bordered
              dataSource={data}
              renderItem={item => <List.Item>{item}</List.Item>}
            />
          </div>
        </div>
      </div>
    )
  }
}

export default Detail
