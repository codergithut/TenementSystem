import React, { Component } from 'react'
import { HashRouter as Router, Route, Switch, Redirect } from 'react-router-dom'
import { Layout, Menu, Icon } from 'antd'
import routes from '../router/index'

const { Footer, Content } = Layout
const RouteConfig = () => (
  <Router>
    <Switch>
      {routes.map((val, i) => (
        <Route path={val.path} key={i} component={val.component} />
      ))}
      <Route path="/" render={() => <Redirect to="/home" />} />
    </Switch>
  </Router>
)

class Nav extends Component {
  constructor(props) {
    super(props)
    this.state = {
      menu: [
        { title: '列表页', url: 'home' },
        { title: '详情页', url: 'detail' }
      ],
      active: 'home'
    }
  }
  handleClick = e => {
    this.setState({ active: e.key })
    this.props.history.push(e.key)
  }
  render() {
    const { active } = this.state
    return (
      <Layout
        style={{ display: 'flex', flexDirection: 'column', height: '100%' }}
      >
        <div style={{ padding: '0 25px', background: '#fff' }}>
          <Menu
            onClick={this.handleClick}
            selectedKeys={[active]}
            mode="horizontal"
          >
            {this.state.menu.map(v => (
              <Menu.Item key={v.url}>
                <Icon type="appstore" />
                {v.title}
              </Menu.Item>
            ))}
          </Menu>
        </div>
        <Content style={{ flex: 1, overflow: 'auto' }}>
          <RouteConfig />
        </Content>
        <Footer style={{ textAlign: 'center' }}>Footer</Footer>
      </Layout>
    )
  }
}

export default () => (
  <Router>
    <Route path="/" component={Nav} />
  </Router>
)
